Phalcon is an open source project and a volunteer effort.

*We only accept bug reports, new feature requests and pull requests in GitHub*.

If you have a question about how to use Phalcon, please see the [support page](http://phalconphp.com/support).

If you have a change or new feature in mind, please fill an [NFR](https://github.com/phalcon/cphalcon/wiki/New-Feature-Request---NFR).

IDE stubs must not be modified manually, if you want to improve them please submit a PR to [cphalcon](https://github.com/phalcon/cphalcon).

Thanks! <br />
Phalcon Team
