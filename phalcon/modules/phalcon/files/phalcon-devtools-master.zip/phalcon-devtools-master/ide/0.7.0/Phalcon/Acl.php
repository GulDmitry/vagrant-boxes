<?php 

namespace Phalcon {

	class Acl {

		const ALLOW = 1;

		const DENY = 0;
	}
}
