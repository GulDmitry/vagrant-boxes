<?php 

namespace Phalcon\Session\Adapter {

	class Files extends \Phalcon\Session\Adapter {
	}
}
