<?php 

namespace Phalcon {

	class Session {
	}
}
