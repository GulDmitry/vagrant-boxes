<?php 

namespace Phalcon {

	class Translate {
	}
}
