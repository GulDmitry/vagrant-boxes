<?php 

namespace Phalcon\Escaper {

	class Exception extends \Phalcon\Exception {
	}
}
