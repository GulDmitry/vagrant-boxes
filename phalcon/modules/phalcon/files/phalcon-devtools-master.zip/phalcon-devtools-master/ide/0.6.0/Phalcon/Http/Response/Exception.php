<?php 

namespace Phalcon\Http\Response {

	class Exception extends \Phalcon\Exception {
	}
}
