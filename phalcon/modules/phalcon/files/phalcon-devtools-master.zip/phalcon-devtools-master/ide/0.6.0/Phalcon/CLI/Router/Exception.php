<?php 

namespace Phalcon\CLI\Router {

	class Exception extends \Phalcon\Exception {
	}
}
