<?php 

namespace Phalcon\Mvc\Collection {

	class Exception extends \Phalcon\Exception {
	}
}
