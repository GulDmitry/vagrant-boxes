<?php 

namespace Phalcon\Mvc\User {

	class Module extends \Phalcon\DI\Injectable {
	}
}
