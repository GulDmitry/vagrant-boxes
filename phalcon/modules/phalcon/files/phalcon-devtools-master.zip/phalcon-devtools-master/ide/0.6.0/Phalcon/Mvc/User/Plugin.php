<?php 

namespace Phalcon\Mvc\User {

	class Plugin extends \Phalcon\DI\Injectable {
	}
}
