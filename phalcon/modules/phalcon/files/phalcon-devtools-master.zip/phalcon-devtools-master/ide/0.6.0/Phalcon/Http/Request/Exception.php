<?php 

namespace Phalcon\Http\Request {

	class Exception extends \Phalcon\Exception {
	}
}
