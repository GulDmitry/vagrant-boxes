<?php 

namespace Phalcon\Mvc\Url {

	class Exception extends \Phalcon\Exception {
	}
}
