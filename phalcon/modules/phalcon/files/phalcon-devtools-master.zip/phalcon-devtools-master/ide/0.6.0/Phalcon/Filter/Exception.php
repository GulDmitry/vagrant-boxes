<?php 

namespace Phalcon\Filter {

	class Exception extends \Phalcon\Exception {
	}
}
