<?php 

namespace Phalcon\CLI {

	class Task extends \Phalcon\DI\Injectable {

		final public function __construct(){ }

	}
}
