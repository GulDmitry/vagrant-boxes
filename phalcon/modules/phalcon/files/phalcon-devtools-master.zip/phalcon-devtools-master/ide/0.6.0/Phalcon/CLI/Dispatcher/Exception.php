<?php 

namespace Phalcon\CLI\Dispatcher {

	class Exception extends \Phalcon\Exception {
	}
}
