<?php 

namespace Phalcon\Paginator {

	class Exception extends \Phalcon\Exception {
	}
}
