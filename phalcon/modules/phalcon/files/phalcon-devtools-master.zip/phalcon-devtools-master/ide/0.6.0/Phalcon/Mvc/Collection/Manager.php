<?php 

namespace Phalcon\Mvc\Collection {

	class Manager {

		protected $_initialized;

		public function __construct(){ }


		public function isInitialized($collection){ }


		public function initialize(){ }

	}
}
