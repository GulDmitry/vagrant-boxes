<?php 

namespace Phalcon\Mvc\Model\Transaction {

	class Exception extends \Phalcon\Mvc\Model\Exception {
	}
}
