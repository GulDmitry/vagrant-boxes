<?php 

namespace Phalcon\DI {

	class Exception extends \Phalcon\Exception {
	}
}
