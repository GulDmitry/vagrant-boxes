<?php 

namespace Phalcon\Db {

	class Exception extends \Phalcon\Exception {
	}
}
