<?php 

namespace Phalcon {

	class Exception extends \Exception {
	}
}
