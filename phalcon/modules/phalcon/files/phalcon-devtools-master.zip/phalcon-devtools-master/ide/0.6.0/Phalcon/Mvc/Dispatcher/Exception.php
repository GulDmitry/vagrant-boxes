<?php 

namespace Phalcon\Mvc\Dispatcher {

	class Exception extends \Phalcon\Exception {
	}
}
