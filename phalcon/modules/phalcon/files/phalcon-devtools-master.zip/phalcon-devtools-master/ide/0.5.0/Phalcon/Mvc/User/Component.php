<?php 

namespace Phalcon\Mvc\User {

	class Component extends \Phalcon\DI\Injectable {

		protected $_dependencyInjector;

		protected $_eventsManager;
	}
}
