<?php 

namespace Phalcon\Internal {

	class TestParent {

		private $_pp0;

		public function mp1(){ }


		public function mp2($a, $b){ }


		public function mp7(){ }


		protected static function smp1(){ }


		protected static function smp3(){ }


		protected static function smp6(){ }

	}
}
