<?php 

namespace Phalcon\Session\Adapter {

	class Files extends \Phalcon\Session {

		protected $_uniqueId;

		protected $_started;

		protected $_options;
	}
}
