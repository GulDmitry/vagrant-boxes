<?php 

namespace Phalcon\Internal {

	class Test extends \Phalcon\Internal\TestParent {
	}
}
