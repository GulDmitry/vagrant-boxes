<?php 

namespace Phalcon {

	class Test {

		public function nice(){ }

	}
}
