<?php 

namespace Phalcon\Internal {

	class TestDummy {

		private $_d1;

		public function __construct($p1){ }


		public function f1($p1){ }


		public function f2(){ }


		public function f3($d1){ }

	}
}
