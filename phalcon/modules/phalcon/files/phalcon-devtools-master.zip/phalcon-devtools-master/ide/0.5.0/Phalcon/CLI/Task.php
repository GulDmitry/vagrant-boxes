<?php 

namespace Phalcon\CLI {

	class Task extends \Phalcon\DI\Injectable {

		protected $_dependencyInjector;

		protected $_eventsManager;

		final public function __construct(){ }

	}
}
