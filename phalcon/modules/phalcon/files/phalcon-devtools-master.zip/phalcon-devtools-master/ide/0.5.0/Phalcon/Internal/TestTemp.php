<?php 

namespace Phalcon\Internal {

	class TestTemp {

		public function e5a(){ }


		public function e9a(){ }


		public function e10a(){ }


		public function e13a(){ }


		public function e13b(){ }


		public function e13c(){ }


		public function e13d(){ }


		public function e14($val){ }


		public function e15(){ }

	}
}
